```
from tanvircalculator import calculator

result = calculator.add(5, 3)
print(result)  # Output: 8

```
```
from tanvircalculator import calculator

result = calculator.subtract(5, 3)
print(result)  # Output: 2

```
```
from tanvircalculator import calculator

result = calculator.multiply(5, 3)
print(result)  # Output: 15

```
```
from simple-calculator-py import calculator

result = calculator.divide(10, 2)
print(result)  # Output: 5

```

