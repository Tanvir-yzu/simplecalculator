
from tanvircalculator import calculator

result = calculator.add(5, 3)
print(result)  # Output: 8
