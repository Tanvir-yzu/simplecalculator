```
from simplecalculator import calculator

result = calculator.add(5, 3)
print(result)  # Output: 8

```
```
from simplecalculator import calculator

result = calculator.subtract(5, 3)
print(result)  # Output: 2

```
```
from simplecalculator import calculator

result = calculator.multiply(5, 3)
print(result)  # Output: 15

```
```
from simplecalculator import calculator

result = calculator.divide(10, 2)
print(result)  # Output: 5

```

