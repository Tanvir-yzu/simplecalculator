
from simplecalculator import calculator

result = calculator.multiply(5, 3)
print(result)  # Output: 8
